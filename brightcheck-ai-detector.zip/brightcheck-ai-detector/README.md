# BrightCheck — AI Text Detector Demo

A colourful, responsive, cartoon-themed AI-writing analysis demo built with plain HTML, CSS and JavaScript.

## Run locally
Open `index.html` in a browser. No installation or build step is needed.

## Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site.

## Important limitation
This is a frontend prototype. Its score is a transparent heuristic based on sentence-length uniformity, repeated three-word phrases, and a small list of common expressions. It is **not** a validated AI detector and does not determine authorship. Do not use its score for accusations, grading, hiring, or disciplinary decisions.

All analysis happens in the browser; entered text is not uploaded to a server.
